import sys
from flask import Flask, jsonify, render_template

COMMAND     = None
SERVER_PORT = '8080'

app = Flask(__name__)
app.config['SECRET_KEY'] = 'my-powerpoint-game-is-strong' 

@app.route("/", methods=['GET']) 

@app.route("/index/", methods=['GET'])
def index():
    global COMMAND
    
    return render_template('index.html')  

@app.route("/command/")
def command():
    global COMMAND
    
    returnvalue = jsonify({'command': COMMAND})
    COMMAND = None
    
    return (returnvalue)
    
@app.route("/setcmdnext/")
def setcmdnext():
    global COMMAND
    COMMAND = 'next'
    return jsonify({'command': COMMAND})
    
@app.route("/setcmdback/")
def setcmdback():
    global COMMAND
    COMMAND = 'back'
    return jsonify({'command': COMMAND})


@app.route("/setcmdstop/")
def setcmdstop():
    global COMMAND
    COMMAND = 'stop'
    return jsonify({'command': COMMAND})


@app.route("/setcmdhome/")
def setcmdhome():
    global COMMAND
    COMMAND = 'home'
    return jsonify({'command': COMMAND})


@app.route("/setcmdend/")
def setcmdend():
    global COMMAND
    COMMAND = 'end'
    return jsonify({'command': COMMAND})


def main(argv):
    app.run(host='0.0.0.0', port=SERVER_PORT)

if __name__ == '__main__':
    main(sys.argv[1:])  